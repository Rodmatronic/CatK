# CatK root SH profile

export HOME=/root
export PS1="\u$ "
